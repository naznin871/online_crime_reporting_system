<?php 
$host="sql102.hstn.me";
$user="mseet_27526132";
$pass="bannanila352443";
$dbname="mseet_27526132_online_crime_report";
$conn=mysqli_connect($host,$user,$pass,$dbname);
 ?>