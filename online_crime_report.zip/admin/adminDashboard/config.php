<?php 
$host="localhost";
$user="root";
$pass="";
$dbname="online_crime_report";
$conn=mysqli_connect($host,$user,$pass,$dbname);
 ?>