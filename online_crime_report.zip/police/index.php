<?php include "layout/header.php"; ?>
<div class="content" style="background: url('../images/police.png') no-repeat;background-position: center;background-size: cover;"></div>
<?php include "layout/footer.php"; ?>